extern void a1_function (void);
extern void a2_function (void);

void a2_function (void)
{
  a1_function ();
}
