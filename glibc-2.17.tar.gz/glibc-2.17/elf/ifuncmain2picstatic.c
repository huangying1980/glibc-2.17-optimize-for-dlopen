/* Test STT_GNU_IFUNC symbols with -fPIC and -static.  */

#include "ifuncmain2.c"
