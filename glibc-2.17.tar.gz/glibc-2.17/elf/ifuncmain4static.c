/* Test STT_GNU_IFUNC symbols with -static.  */

#include "ifuncmain4.c"
