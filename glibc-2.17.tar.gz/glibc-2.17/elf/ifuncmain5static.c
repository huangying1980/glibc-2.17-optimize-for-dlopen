/* Test STT_GNU_IFUNC symbols with -static.  */

#include "ifuncmain5.c"
